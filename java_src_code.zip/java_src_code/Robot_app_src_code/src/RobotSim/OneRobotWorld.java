/**
 * 
 */
package RobotSim;

/**
 * @author shsmchlr
 *
 */
public class OneRobotWorld {
	private double RobotX, RobotY, RobotRad, RobotAngle, RobotSpeed;
		// position and size of Robot + angle traveling and speed
	
	public OneRobotWorld() {
		RobotX = 100;
		RobotY = 180;
		RobotRad = 20;
		RobotAngle = 45;
		RobotSpeed = 5;
	}
	/**
	 * function to check where Robot is, and adjust angle if is hitting side of canvas
	 * @param xSize		max x size of arena
	 * @param ySize
	 */
	public void checkRobot(MyCanvas mc) {
		if (RobotX < RobotRad || RobotX > mc.getXCanvasSize() - RobotRad) RobotAngle = 180 - RobotAngle;
			// if Robot hit (tried to go through) left or right walls, set mirror angle, being 180-angle
		if (RobotY < RobotRad || RobotY > mc.getYCanvasSize() - RobotRad) RobotAngle = -RobotAngle;
			// if Robot hit (tried to go through) top or bottom walls, set mirror angle, being -angle
	}
	/**
	 * move the Robot according to speed and angle
	 */
	public void adjustRobot() {
		double radAngle = RobotAngle*Math.PI/180;	// put angle in radians
		RobotX += RobotSpeed * Math.cos(radAngle);		// new X position
		RobotY += RobotSpeed * Math.sin(radAngle);		// new Y position
	}
	/**
	 * update the world -
	 * @param mc	canvas in which drawn
	 */
	public void updateWorld(MyCanvas mc) {
		checkRobot(mc);			// check if about to hit side of wall, adjust angle if so
		adjustRobot();			// calculate new position
	}
	/**
	 * draw the Robot into the canvas mc
	 * @param mc
	 */
	public void drawWorld(MyCanvas mc) {
		mc.clearCanvas();
		mc.showRobot(RobotX, RobotY, RobotRad, 'r');					// call interface's routine
	}
	/**
	 * set Robot to position x,y
	 * @param x
	 * @param y
	 */
	public void setXY(double x, double y) {
		RobotX = x;
		RobotY = y;
	}

	/**
	 * return string describing Robot and its position
	 */
	public String toString() {
		return "Robot at " + Math.round(RobotX) + ", " + Math.round(RobotY);
	}

}
