/**
 * 
 */
package RobotSim;

/**
 * @author 31015352
 *
 */
public class PaddleRobot extends Robot {
	private static final long serialVersionUID = 1L;

	/**
	 * Set up the paddle controlled by the user
	 */
	public PaddleRobot() {
		// TODO Auto-generated constructor stub
	}

	/**Set paddle Robot size ir at ix,iy
	 * @param ix
	 * @param iy
	 * @param ir
	 */
	public PaddleRobot(double ix, double iy, double ir) {
		super(ix, iy, ir);
		col = 'b';
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see uk.ac.reading.profrichardmitchell83.Robot#checkRobot(uk.ac.reading.profrichardmitchell83.RobotArena)
	 */
	@Override
	protected void checkRobot(RobotArena b) {
		// nowt to do
	}

	/* (non-Javadoc)
	 * @see uk.ac.reading.profrichardmitchell83.Robot#adjustRobot()
	 */
	@Override
	protected void adjustRobot() {
		// nowt to do 
	}
	/**
	 *  return string description as paddle
	 */
	protected String getStrType() {
		return "Paddle";
	}	
}
