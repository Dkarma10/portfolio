/**
 * 
 */
package RobotSim;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author 31015352
 * Class for Arena of robots
 */
public class RobotArena implements Serializable {	
	private static final long serialVersionUID = 1L;
	private double xSize, ySize;						// size of arena
	private ArrayList<Robot> allRobots;			// array list of all robots in arena
	/**
	 * construct an arena
	 */
	RobotArena() {
		this(500, 400);			// default size
	}
	/**
	 * construct arena of size xS by yS
	 * @param xS
	 * @param yS
	 */
	RobotArena(double xS, double yS){
		xSize = xS;
		ySize = yS;
		allRobots = new ArrayList<Robot>();					// list of all robots, initially empty
		
		allRobots.add(new PaddleRobot(xS/2, yS-20, 20));		// add paddle
		
	}
	/**
	 * return arena size in x direction
	 * @return
	 */
	public double getXSize() {
		return xSize;
	}
	/**
	 * return arena size in y direction
	 * @return
	 */
	public double getYSize() {
		return ySize;
	}
	/**
	 * draw all robots in the arena into interface bi
	 * @param bi
	 */
	public void drawArena(MyCanvas mc) {
		for (Robot b : allRobots) b.drawRobot(mc);		// draw all robots
	}
	/**
	 * check all robots .. see if need to change angle of moving robots, etc 
	 */
	public void checkrobots() {
		for (Robot b : allRobots) b.checkRobot(this);	// check all robots
	}
	/**
	 * adjust all robots .. move any moving ones
	 */
	public void adjustrobots() {
		for (Robot b : allRobots) b.adjustRobot();
	}
	/** 
	 * set the paddle robot at x,y
	 * @param x
	 * @param y
	 */
	public void setPaddle(double x, double y) {
		for (Robot b : allRobots)
			if (b instanceof PaddleRobot) b.setXY(x, y);
	}
	/**
	 * return list of strings defining each robot
	 * @return
	 */
	public ArrayList<String> describeAll() {
		ArrayList<String> ans = new ArrayList<String>();		// set up empty arraylist
		for (Robot b : allRobots) ans.add(b.toString());			// add string defining each robot
		return ans;												// return string list
	}
	/** 
	 * Check angle of robot ... if hitting wall, rebound; if hitting robot, change angle
	 * @param x				robot x position
	 * @param y				y
	 * @param rad			radius
	 * @param ang			current angle
	 * @param notID			identify of robot not to be checked
	 * @return				new angle 
	 */
	public double CheckRobotAngle(double x, double y, double rad, double ang, int notID) {
		double ans = ang;
		if (x < rad || x > xSize - rad) ans = 180 - ans;
			// if robot hit (tried to go through) left or right walls, set mirror angle, being 180-angle
		if (y < rad || y > ySize - rad) ans = - ans;
			// if try to go off top or bottom, set mirror angle
		
		for (Robot b : allRobots) 
			if (b.getID() != notID && b.hitting(x, y, rad)) ans = 180*Math.atan2(y-b.getY(), x-b.getX())/Math.PI;
				// check all robots except one with given id
				// if hitting, return angle between the other robot and this one.
		
		return ans;		// return the angle
	}

	/**
	 * check if the target robot has been hit by another robot
	 * @param target	the target robot
	 * @return 	true if hit
	 
	public boolean checkHit(Robot target) {
		boolean ans = false;
		for (Robot b : allRobots)
			//if (b instanceof GameRobot && b.hitting(target)) ans = true;
				// try all robots, if Gamerobot, check if hitting the target
		return ans;
	}
	
	public void addrobot() {
		allRobots.add(new GameRobot(xSize/2, ySize/2, 10, 60, 5));
	}
	
	/**
	 * Load the arena with the set up in the given file 
	 * @param fname
	 * @return 0 if successful
	 */
	public int loadFile (String fname) {
		int status = 0;
		allRobots.clear();
	      try {
	    	  FileInputStream fileInputStream = new FileInputStream(fname);					// set up input stream
	    	  ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);		// and file
	    	  RobotArena A = (RobotArena) inputStream.readObject();							// read whole object
	    	  this.xSize = A.xSize;															// load into arena
	    	  this.ySize = A.ySize;
	    	  this.allRobots = A.allRobots;
	    	  inputStream.close();															// close...
	    	  fileInputStream.close();
	      } catch(IOException e) {
	    	  e.printStackTrace();
	    	  status = 1;
	      }
	      catch(ClassNotFoundException c) {
	    	  c.printStackTrace();
	    	  status = 2; 
	      }
	      return status;
	}
	/**
	 * save the arena and its contents into the named file
	 * @param fname
	 * @return 0 if ok
	 */
	public int saveFile (String fname) {
		int status = 0;
	      try {
	    	  FileOutputStream fileOutputStream = new FileOutputStream(fname);				// setup
	    	  ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);		
	    	  outputStream.writeObject(this);												// write arena and contents
	    	  outputStream.close();															// close
	    	  fileOutputStream.close();
	      } catch(IOException e) {
	    	  e.printStackTrace();
	    	  status = 1;
	      }
	      return status;
	}	

}
